-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 01-12-2024 a las 06:39:11
-- Versión del servidor: 8.3.0
-- Versión de PHP: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bdproyect`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `edit` varchar(255) NOT NULL,
  `lang` varchar(255) NOT NULL,
  `pages` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `ejemplares` varchar(255) NOT NULL,
  `stock` int NOT NULL,
  `available` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `books`
--

INSERT INTO `books` (`id`, `title`, `date`, `author`, `category`, `edit`, `lang`, `pages`, `description`, `ejemplares`, `stock`, `available`) VALUES
(1, 'Sapiens: De animales a dioses', '2011', 'Yuval Noah Harari', 'Historia', '1', 'Ingles', '512', 'Explora la historia de la humanidad desde una perspectiva evolutiva y sociocultural.', '1000', 10, 10),
(2, 'Harry Potter y las reliquias de la muerte', '2007', 'J.K. Rowling', 'Fantasía ', '1', 'Ingles', '759', 'La batalla final de Harry Potter contra el mal en el desenlace de la serie.', '2000', 20, 20),
(3, 'La sombra del viento', '2001', 'Carlos Ruiz Zafón', 'Misterio ', '1', 'Español', '576', 'Un joven descubre un libro enigmático que lo lleva a desentrañar secretos oscuros en la Barcelona de posguerra.', '420', 50, 50),
(4, 'El psicoanalista', '2002', 'John Katzenbach', 'Thriller psicológico', '1', 'Ingles', '528', 'Un psicoterapeuta es amenazado por un desconocido que promete destruir su vida si no resuelve un enigma. ', '250', 25, 25),
(5, '100 años de soledad', '2000', 'García Marquez', 'Tragedia', '1', 'Español', '400', 'Buena historia', '1200', 25, 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lendings`
--

DROP TABLE IF EXISTS `lendings`;
CREATE TABLE IF NOT EXISTS `lendings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `book_id` int NOT NULL,
  `date_out` varchar(255) NOT NULL,
  `date_return` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `lendings`
--

INSERT INTO `lendings` (`id`, `user_id`, `book_id`, `date_out`, `date_return`) VALUES
(1, 1, 1, '11-11-2024', '11-11-2024'),
(2, 1, 1, '13-11-2024', '13-11-2024'),
(3, 1, 1, '30-11-2024', '30-11-2024'),
(4, 2, 1, '01-12-2024', '01-12-2024');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `partnerts`
--

DROP TABLE IF EXISTS `partnerts`;
CREATE TABLE IF NOT EXISTS `partnerts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `partnerts`
--

INSERT INTO `partnerts` (`id`, `name`, `username`, `password`) VALUES
(1, 'Marcelo Manrique', 'Marcelo', '12345'),
(2, 'Leslie Raymundo', 'Leslie', '54321');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `last_name_p` varchar(30) NOT NULL,
  `last_name_m` varchar(30) NOT NULL,
  `domicilio` varchar(250) DEFAULT NULL,
  `tel` varchar(25) DEFAULT NULL,
  `sanctions` int DEFAULT '0',
  `sanc_money` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `last_name_p`, `last_name_m`, `domicilio`, `tel`, `sanctions`, `sanc_money`) VALUES
(1, 'Itza', 'Carballo', 'Flores', 'Av. Mexico 132', '512512', 0, 0),
(2, 'Marcelo', 'Manrique', 'Diaz', 'Av. Peru 1241', '514233', 0, 0),
(3, 'Melissa ', 'Robles', 'Garcia', 'Av. Monterrey 1412', '111111', 0, 0),
(4, 'Catalina', 'Manrique', 'Diaz', 'Av.hola', '412421', 0, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
